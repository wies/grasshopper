#include <stdlib.h>

int makeStrFromInt(int myInt){
  char c = myInt + '0';
  return c;
}
